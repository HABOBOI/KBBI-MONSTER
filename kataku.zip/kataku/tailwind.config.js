module.exports={content:['./app/**/*.tsx'],theme:{extend:{fontFamily:{sans:['var(--font-inter)','sans-serif'],display:['var(--font-display)','sans-serif']}}},plugins:[]}
