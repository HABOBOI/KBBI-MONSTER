'use client'
import {useCallback,useEffect,useMemo,useRef,useState} from 'react'
import {AnimatePresence,motion} from 'framer-motion'
import {Home as HomeI,BarChart3,BookX,User,Flame,Heart,X as XI,Trophy} from 'lucide-react'
import {LineChart,Line,XAxis,YAxis,Tooltip,BarChart,Bar,ResponsiveContainer} from 'recharts'
import {WORDS,Word,Lvl} from '@/lib/words'
import {useStore,today,Sess,Rec,St} from '@/lib/store'

type Cfg={key:string;label:string;desc?:string;n?:number;secs?:number;levels?:Lvl[];daily?:boolean;practice?:boolean;ids?:number[]}
type Q={w:Word;baku:boolean;flip:boolean}
type Ans={id:number;ok:boolean}
type View='home'|'modes'|'quiz'|'result'|'stats'|'weak'|'profile'
const MODES:Cfg[]=[
 {key:'quick',label:'Quick Quiz',desc:'10 soal · 1 menit',n:10,secs:60},
 {key:'standard',label:'Standard Quiz',desc:'20 soal · 3 menit',n:20,secs:180},
 {key:'hard',label:'Hard Quiz',desc:'30 soal · 5 menit · kata lebih sulit',n:30,secs:300,levels:['Medium','Hard','Expert']},
 {key:'endless',label:'Endless Mode',desc:'Tanpa batas waktu, berhenti kapan saja'},
 {key:'practice',label:'Practice Mode',desc:'Tanpa timer, lihat arti, simpan favorit',practice:true}]
const DAILY:Cfg={key:'daily',label:'Daily Challenge',desc:'10 soal unik hari ini',n:10,secs:150,daily:true}
const BASE={Easy:10,Medium:15,Hard:20,Expert:30}
const COMBO:Record<number,number>={3:10,5:20,10:50}
const lvl=(xp:number)=>Math.floor(Math.sqrt(xp/40))+1
const fmt=(ms:number)=>{const s=Math.ceil(ms/1000);return `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`}
const pct=(r?:Rec)=>r&&r.a?Math.round(r.c/r.a*100):0
function seeded(s:string){let h=1779033703^s.length;for(const ch of s){h=Math.imul(h^ch.charCodeAt(0),3432918353);h=h<<13|h>>>19}let a=h;return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function shuffle<T>(x:T[],r:()=>number){const a=[...x];for(let i=a.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function build(c:Cfg):Q[]{
 const rnd=c.daily?seeded(today()):Math.random
 const pool=WORDS.filter(w=>(!c.levels||c.levels.includes(w.level))&&(!c.ids||c.ids.includes(w.id)))
 const rounds=c.n&&c.n<=pool.length?1:Math.ceil((c.n||200)/pool.length)
 let out:Q[]=[]
 for(let r=0;r<rounds;r++)out=out.concat(shuffle(pool,rnd).map(w=>({w,baku:rnd()<.5,flip:rnd()<.5})))
 return c.n?out.slice(0,c.n):out
}
function rec(st:St){
 const cat:Record<string,Rec>={}
 WORDS.forEach(w=>{const r=st.words[w.id];if(r){const c=cat[w.kategori]||(cat[w.kategori]={a:0,c:0});c.a+=r.a;c.c+=r.c}})
 const l=Object.entries(cat).filter(([,r])=>r.a>=3).sort((x,y)=>pct(x[1])-pct(y[1]))
 if(!l.length)return 'Selesaikan beberapa sesi dulu, nanti saran latihan muncul di sini.'
 const [k,r]=l[0]
 return pct(r)>=90?'Akurasimu bagus di semua kategori. Coba Hard Quiz untuk tantangan baru!':`Kategori ${k} paling lemah (${pct(r)}%). Coba Practice Mode atau Latih Kata Lemah.`
}
const BADGES:[string,string,(s:St)=>boolean][]=[
 ['Langkah Pertama','Selesaikan 1 sesi',s=>s.sessions.length>=1],
 ['50 Soal','Jawab 50 soal',s=>tot(s)>=50],
 ['Seratus','Jawab 100 soal',s=>tot(s)>=100],
 ['Pemburu Combo','Combo 10 berturut-turut',s=>s.bestCombo>=10],
 ['Rajin','Streak 3 hari',s=>s.streak>=3],
 ['Sempurna','100% di sesi ≥10 soal',s=>s.sessions.some(x=>x.a>=10&&x.a===x.c)],
 ['Naik Level','Capai level 3',s=>lvl(s.xp)>=3],
 ['Daily Hero','Selesaikan Daily Challenge',s=>!!s.lastDaily]]
const tot=(s:St)=>Object.values(s.words).reduce((n,r)=>n+r.a,0)
const card='rounded-3xl bg-white p-5 shadow-lg shadow-indigo-100'
const big='w-full rounded-2xl bg-indigo-600 py-4 text-lg font-extrabold text-white shadow-lg shadow-indigo-200 active:scale-95 transition'

function Quiz({cfg,onEnd}:{cfg:Cfg;onEnd:(s:Sess,a:Ans[],q:Q[])=>void}){
 const qs=useMemo(()=>build(cfg),[cfg])
 const {fav,toggleFav}=useStore()
 const [i,setI]=useState(0),[score,setScore]=useState(0),[combo,setCombo]=useState(0)
 const [picked,setPicked]=useState<boolean|null>(null),[left,setLeft]=useState((cfg.secs||0)*1000)
 const ans=useRef<Ans[]>([]),t0=useRef(Date.now()),tq=useRef(Date.now()),nx=useRef<any>(null),done=useRef(false),st=useRef({score:0,combo:0,best:0})
 const finish=useCallback(()=>{if(done.current)return;done.current=true;clearTimeout(nx.current)
  const a=ans.current;onEnd({ts:Date.now(),mode:cfg.key,score:st.current.score,a:a.length,c:a.filter(x=>x.ok).length,best:st.current.best,secs:Math.round((Date.now()-t0.current)/1000)},a,qs)},[cfg,qs,onEnd])
 useEffect(()=>{if(!cfg.secs)return;const end=t0.current+cfg.secs*1000
  const id=setInterval(()=>{const l=end-Date.now();setLeft(Math.max(0,l));if(l<=0){clearInterval(id);finish()}},100)
  return()=>clearInterval(id)},[cfg.secs,finish])
 useEffect(()=>()=>clearTimeout(nx.current),[])
 const q=qs[i]
 const next=()=>{clearTimeout(nx.current);if(i+1>=qs.length)return finish();setI(i+1);setPicked(null);tq.current=Date.now()}
 const pick=(b:boolean)=>{if(picked!==null)return
  const ok=b===q.baku,s=st.current,sec=(Date.now()-tq.current)/1000;let pts=0
  if(ok){s.combo++;s.best=Math.max(s.best,s.combo);pts=BASE[q.w.level]+(cfg.practice?0:Math.max(0,Math.round(5-sec))*2)+(COMBO[s.combo]||0)}else s.combo=0
  s.score+=pts;ans.current.push({id:q.w.id,ok});setPicked(b);setScore(s.score);setCombo(s.combo)
  if(!cfg.practice)nx.current=setTimeout(next,ok?800:2400)}
 const ok=picked===q.baku,low=!!cfg.secs&&left<=10000,mid=!!cfg.secs&&left<cfg.secs*400
 const opts=q.flip?[false,true]:[true,false]
 return <div className="space-y-4">
  <div className="flex items-center gap-3">
   <button onClick={finish} aria-label="Selesai" className="rounded-xl bg-white p-2 shadow"><XI size={18}/></button>
   <div className="h-3 flex-1 overflow-hidden rounded-full bg-slate-200"><div className={`h-full ${low?'animate-pulse bg-rose-500':mid?'bg-amber-400':'bg-indigo-500'}`} style={{width:cfg.secs?`${left/(cfg.secs*10)}%`:cfg.n?`${i/cfg.n*100}%`:'0%'}}/></div>
   <span className={`font-display text-xl font-extrabold tabular-nums ${low?'text-rose-600':''}`}>{cfg.secs?fmt(left):'∞'}</span>
  </div>
  <div className="flex items-center justify-between text-sm font-semibold text-slate-500">
   <span>{cfg.n?`${i+1}/${cfg.n}`:`Soal ${i+1}`}</span>
   <motion.span key={combo} initial={{scale:.5}} animate={{scale:1}} transition={{type:'spring',stiffness:500,damping:12}} className={`font-extrabold ${combo>=3?'text-orange-500':''}`}>{combo>=2?`🔥 x${combo}`:''}</motion.span>
   <span>Skor {score}</span>
  </div>
  <AnimatePresence mode="wait"><motion.div key={i} initial={{opacity:0,x:40}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-40}} transition={{duration:.2}} className={card+' text-center'}>
   <p className="text-slate-500">Kata berikut merupakan kata …?</p>
   <motion.div animate={picked===null?{scale:1}:ok?{scale:[1,1.08,1]}:{x:[0,-10,10,-6,6,0]}} className={`my-8 break-words font-display text-5xl font-extrabold sm:text-7xl ${picked===null?'':ok?'text-emerald-600':'text-rose-600'}`}>{q.baku?q.w.baku:q.w.tidak}</motion.div>
   {cfg.practice&&<button onClick={()=>toggleFav(q.w.id)} className="mx-auto flex items-center gap-1 text-sm text-rose-500"><Heart size={16} fill={fav.includes(q.w.id)?'currentColor':'none'}/>Favorit</button>}
  </motion.div></AnimatePresence>
  <div className="grid grid-cols-2 gap-3">{opts.map(b=>{const right=picked!==null&&b===q.baku,wrong=picked===b&&b!==q.baku
   return <motion.button whileTap={{scale:.95}} key={String(b)} disabled={picked!==null} onClick={()=>pick(b)} className={`rounded-2xl px-3 py-4 text-lg font-bold shadow ${right?'bg-emerald-500 text-white':wrong?'bg-rose-500 text-white':'bg-white'}`}>{b?'Baku':'Tidak Baku'}<span className="block text-xs font-medium opacity-70">{b?'Sesuai KBBI':'Tidak sesuai KBBI'}</span></motion.button>})}</div>
  {picked!==null&&<motion.div initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} className={`rounded-2xl p-4 ${ok?'bg-emerald-50 text-emerald-800':'bg-rose-50 text-rose-800'}`}>
   <p className="font-bold">{ok?'Benar!':'Belum tepat'}</p>
   {(!ok||cfg.practice)&&<><p className="mt-1 text-sm">Yang baku: <b>{q.w.baku}</b> (bukan {q.w.tidak}). Arti: {q.w.arti}. Sumber: KBBI VI Daring.</p><button onClick={next} className="mt-3 w-full rounded-xl bg-indigo-600 py-2 font-bold text-white">Lanjut</button></>}
  </motion.div>}
 </div>
}

export default function Page(){
 const [m,setM]=useState(false);useEffect(()=>setM(true),[])
 const st=useStore()
 const [v,setV]=useState<View>('home'),[cfg,setCfg]=useState<Cfg>(MODES[0]),[run,setRun]=useState(0),[res,setRes]=useState<any>(null)
 const start=(c:Cfg)=>{setCfg(c);setRun(r=>r+1);setV('quiz')}
 const onEnd=useCallback((s:Sess,a:Ans[],qs:Q[])=>{
  if(!a.length){setV('home');return}
  const before=lvl(useStore.getState().xp);useStore.getState().save(s,a,!!cfg.daily)
  setRes({s,a,up:lvl(useStore.getState().xp)>before,key:cfg.key});setV('result')},[cfg])
 if(!m)return <div className="flex min-h-screen items-center justify-center"><motion.div animate={{scale:[1,1.2,1]}} transition={{repeat:Infinity,duration:1}} className="font-display text-4xl font-extrabold text-indigo-600">KATAKU</motion.div></div>
 const L=lvl(st.xp),base=40*(L-1)**2,nextXp=40*L*L,td=st.days[today()]?.a||0
 const weak=WORDS.filter(w=>{const r=st.words[w.id];return r&&r.a>=1&&pct(r)<70}).sort((a,b)=>pct(st.words[a.id])-pct(st.words[b.id]))
 const dailyDone=st.lastDaily===today()
 const days=[...Array(7)].map((_,k)=>{const d=new Date(Date.now()-(6-k)*864e5);const r=st.days[d.toLocaleDateString('sv')];return{d:`${d.getDate()}/${d.getMonth()+1}`,acc:r?pct(r):null}})
 const grp=(f:(w:Word)=>string)=>{const o:Record<string,Rec>={};WORDS.forEach(w=>{const r=st.words[w.id];if(r){const c=o[f(w)]||(o[f(w)]={a:0,c:0});c.a+=r.a;c.c+=r.c}});return Object.entries(o).map(([n,r])=>({n,acc:pct(r)}))}
 const secs=st.sessions.reduce((n,s)=>n+s.secs,0),A=tot(st),C=Object.values(st.words).reduce((n,r)=>n+r.c,0)
 const Tile=({t,x}:{t:string;x:string|number})=><div className={card+' !p-4'}><p className="text-xs text-slate-500">{t}</p><p className="font-display text-2xl font-extrabold">{x}</p></div>
 const nav:[View,any,string][]=[['home',HomeI,'Beranda'],['stats',BarChart3,'Statistik'],['weak',BookX,'Kata Lemah'],['profile',User,'Profil']]
 let body:React.ReactNode=null
 if(v==='home')body=<div className="space-y-5">
  <div><p className="text-slate-500">Halo, jagoan KBBI!</p><h1 className="font-display text-3xl font-extrabold">Sudah latihan hari ini?</h1></div>
  <div className={card}><div className="flex justify-between font-bold"><span>Level {L}</span><span className="flex items-center gap-1 text-orange-500"><Flame size={18}/>{st.streak} hari</span></div>
   <div className="mt-3 h-3 overflow-hidden rounded-full bg-indigo-100"><div className="h-full bg-indigo-500" style={{width:`${(st.xp-base)/(nextXp-base)*100}%`}}/></div><p className="mt-1 text-xs text-slate-500">{st.xp} / {nextXp} XP</p></div>
  <div className={card}><p className="font-bold">Target hari ini: {Math.min(td,10)}/10 soal</p><div className="mt-3 h-3 overflow-hidden rounded-full bg-emerald-100"><div className="h-full bg-emerald-500" style={{width:`${Math.min(td,10)*10}%`}}/></div></div>
  <button className={big} onClick={()=>setV('modes')}>Mulai Quiz</button>
  <button disabled={dailyDone} onClick={()=>start(DAILY)} className={card+' w-full text-left disabled:opacity-60'}><p className="font-bold">Daily Challenge {dailyDone&&'✓'}</p><p className="text-sm text-slate-500">{dailyDone?'Selesai! Kembali lagi besok.':'10 soal unik hari ini, jaga streak-mu'}</p></button></div>
 if(v==='modes')body=<div className="space-y-3"><h1 className="font-display text-3xl font-extrabold">Pilih mode</h1>
  {MODES.slice(0,3).map(c=><button key={c.key} onClick={()=>start(c)} className={card+' w-full text-left'}><p className="font-bold">{c.label}</p><p className="text-sm text-slate-500">{c.desc}</p></button>)}
  <div className={card}><p className="font-bold">Time Attack</p><p className="mb-3 text-sm text-slate-500">Jawab sebanyak mungkin sampai waktu habis</p><div className="grid grid-cols-4 gap-2">{[1,3,5,10].map(n=><button key={n} onClick={()=>start({key:'ta',label:'Time Attack',secs:n*60})} className="rounded-xl bg-indigo-50 py-2 font-bold text-indigo-700 active:scale-95">{n} mnt</button>)}</div></div>
  {MODES.slice(3).map(c=><button key={c.key} onClick={()=>start(c)} className={card+' w-full text-left'}><p className="font-bold">{c.label}</p><p className="text-sm text-slate-500">{c.desc}</p></button>)}
  <button disabled={dailyDone} onClick={()=>start(DAILY)} className={card+' w-full text-left disabled:opacity-60'}><p className="font-bold">Daily Challenge {dailyDone&&'✓'}</p><p className="text-sm text-slate-500">{DAILY.desc}</p></button></div>
 if(v==='quiz')body=<Quiz key={run} cfg={cfg} onEnd={onEnd}/>
 if(v==='result'&&res){const {s,a}=res;const wr=Array.from(new Set<number>(a.filter((x:Ans)=>!x.ok).map((x:Ans)=>x.id))).map(id=>WORDS.find(w=>w.id===id)!)
  body=<div className="space-y-4"><motion.div initial={{scale:.9,opacity:0}} animate={{scale:1,opacity:1}} className={card+' text-center'}><p className="text-slate-500">Skor akhir</p><p className="font-display text-6xl font-extrabold text-indigo-600">{s.score}</p>
   <p className="mt-2 text-sm">Akurasi {Math.round(s.c/s.a*100)}% · {s.c}/{s.a} benar · combo terbaik {s.best}{res.up&&' · Naik level! 🎉'}</p></motion.div>
   <div className={card+' text-sm'}><b>Saran:</b> {rec(st)}</div>
   {wr.length>0&&<div className={card}><p className="mb-2 font-bold">Review kesalahan</p>{wr.map(w=><p key={w.id} className="border-t py-2 text-sm"><b>{w.baku}</b> (bukan {w.tidak}) — {w.arti}</p>)}
    <button className={big+' mt-3'} onClick={()=>start({key:'review',label:'Latih Kata yang Salah',n:wr.length,ids:wr.map(w=>w.id)})}>Latih Kata yang Salah</button></div>}
   <button className={big} onClick={()=>start(cfg)}>Main lagi</button><button className="w-full py-2 font-bold text-indigo-600" onClick={()=>setV('home')}>Beranda</button></div>}
 if(v==='stats')body=<div className="space-y-4"><h1 className="font-display text-3xl font-extrabold">Statistik</h1>
  <div className="grid grid-cols-2 gap-3"><Tile t="Total soal" x={A}/><Tile t="Akurasi" x={A?Math.round(C/A*100)+'%':'-'}/><Tile t="Waktu belajar" x={Math.round(secs/60)+' mnt'}/><Tile t="Streak" x={st.streak+' hari'}/></div>
  <div className={card}><p className="mb-2 font-bold">Akurasi 7 hari</p>{A?<ResponsiveContainer width="100%" height={160}><LineChart data={days}><XAxis dataKey="d" fontSize={11}/><YAxis domain={[0,100]} fontSize={11} width={28}/><Tooltip/><Line dataKey="acc" stroke="#4f46e5" strokeWidth={3} connectNulls/></LineChart></ResponsiveContainer>:<p className="text-sm text-slate-500">Belum ada data. Main satu sesi dulu!</p>}</div>
  {([['Per kategori',grp(w=>w.kategori)],['Per tingkat',grp(w=>w.level)]] as [string,{n:string;acc:number}[]][]).map(([t,d])=><div key={t} className={card}><p className="mb-2 font-bold">{t}</p>{d.length?<ResponsiveContainer width="100%" height={Math.max(90,d.length*34)}><BarChart data={d} layout="vertical"><XAxis type="number" domain={[0,100]} hide/><YAxis type="category" dataKey="n" width={110} fontSize={11}/><Tooltip/><Bar dataKey="acc" fill="#6366f1" radius={6}/></BarChart></ResponsiveContainer>:<p className="text-sm text-slate-500">Belum ada data.</p>}</div>)}
  <div className={card+' text-sm'}><b>Saran sesi berikutnya:</b> {rec(st)}</div></div>
 if(v==='weak')body=<div className="space-y-3"><h1 className="font-display text-3xl font-extrabold">Kata Lemah</h1>
  {weak.length?<><button className={big} onClick={()=>start({key:'review',label:'Latih Kata Lemah',n:weak.length,ids:weak.map(w=>w.id)})}>Latih {weak.length} kata ini</button>
   {weak.map(w=><div key={w.id} className={card+' !p-4 flex justify-between'}><span><b>{w.baku}</b> <span className="text-slate-500">bukan {w.tidak}</span></span><span className="font-bold text-rose-600">{pct(st.words[w.id])}%</span></div>)}</>:<p className="text-slate-500">Belum ada kata lemah. Selesaikan beberapa sesi dulu.</p>}</div>
 if(v==='profile')body=<div className="space-y-4"><h1 className="font-display text-3xl font-extrabold">Profil</h1>
  <div className={card+' text-center'}><p className="font-display text-5xl font-extrabold text-indigo-600">Lv {L}</p><p className="text-sm text-slate-500">{st.xp} XP · streak {st.streak} hari</p></div>
  <div className="grid grid-cols-2 gap-3">{BADGES.map(([n,d,f])=>{const on=f(st);return <div key={n} className={card+` !p-4 ${on?'':'opacity-40'}`}><Trophy size={20} className={on?'text-amber-500':'text-slate-400'}/><p className="mt-1 text-sm font-bold">{n}</p><p className="text-xs text-slate-500">{d}</p></div>})}</div>
  <button className="w-full py-2 text-sm text-rose-600" onClick={()=>confirm('Hapus semua progres?')&&st.reset()}>Reset data</button></div>
 return <main className="mx-auto min-h-screen max-w-md px-4 pb-24 pt-6">
  <AnimatePresence mode="wait"><motion.div key={v==='quiz'?'q'+run:v} initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-12}} transition={{duration:.2}}>{body}</motion.div></AnimatePresence>
  {v!=='quiz'&&<nav className="fixed inset-x-0 bottom-0 mx-auto flex max-w-md justify-around border-t bg-white/90 py-2 backdrop-blur">{nav.map(([k,I,t])=><button key={k} onClick={()=>setV(k)} className={`flex flex-col items-center text-xs font-semibold ${v===k?'text-indigo-600':'text-slate-400'}`}><I size={22}/>{t}</button>)}</nav>}
 </main>
}
