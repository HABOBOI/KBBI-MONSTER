import './globals.css'
import {Inter,Bricolage_Grotesque} from 'next/font/google'
const inter=Inter({subsets:['latin'],variable:'--font-inter'})
const disp=Bricolage_Grotesque({subsets:['latin'],variable:'--font-display',weight:['700','800']})
export const metadata={title:'KATAKU – Kuis KBBI',description:'Latihan kata baku vs tidak baku'}
export const viewport={width:'device-width',initialScale:1}
export default function L({children}:{children:React.ReactNode}){return <html lang="id"><body className={`${inter.variable} ${disp.variable} font-sans`}>{children}</body></html>}
