import {create} from 'zustand'
import {persist} from 'zustand/middleware'
export type Rec={a:number;c:number}
export type Sess={ts:number;mode:string;score:number;a:number;c:number;best:number;secs:number}
export type St={xp:number;streak:number;last:string;lastDaily:string;sessions:Sess[];words:Record<number,Rec>;days:Record<string,Rec>;fav:number[];bestCombo:number;
 save:(s:Sess,ans:{id:number;ok:boolean}[],daily:boolean)=>void;toggleFav:(id:number)=>void;reset:()=>void}
export const today=()=>new Date().toLocaleDateString('sv')
const init={xp:0,streak:0,last:'',lastDaily:'',sessions:[],words:{},days:{},fav:[],bestCombo:0}
export const useStore=create<St>()(persist((set)=>({...init,
 save:(s,ans,daily)=>set(o=>{const w={...o.words},d={...o.days},t=today()
  ans.forEach(x=>{const r=w[x.id]||{a:0,c:0};w[x.id]={a:r.a+1,c:r.c+(x.ok?1:0)}})
  const dr=d[t]||{a:0,c:0};d[t]={a:dr.a+s.a,c:dr.c+s.c}
  const y=new Date(Date.now()-864e5).toLocaleDateString('sv')
  const streak=o.last===t?o.streak:o.last===y?o.streak+1:1
  return{words:w,days:d,streak,last:t,lastDaily:daily?t:o.lastDaily,xp:o.xp+Math.floor(s.score/2)+s.c*2,bestCombo:Math.max(o.bestCombo,s.best),sessions:[...o.sessions,s].slice(-200)}}),
 toggleFav:id=>set(o=>({fav:o.fav.includes(id)?o.fav.filter(x=>x!==id):[...o.fav,id]})),
 reset:()=>set(init)}),{name:'kataku-v1'}))
