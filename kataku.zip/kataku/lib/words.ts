export type Lvl='Easy'|'Medium'|'Hard'|'Expert'
export type Word={id:number;baku:string;tidak:string;kategori:string;level:Lvl;arti:string}
const K:Record<string,string>={KK:'Kata Kerja',KB:'Kata Benda',KS:'Kata Sifat',SR:'Kata Serapan',EJ:'Ejaan',BI:'Bentuk Berimbuhan',IS:'Istilah'}
const L:Record<string,Lvl>={E:'Easy',M:'Medium',H:'Hard',X:'Expert'}
// baku|tidak baku|kategori|level|arti  (sumber: KBBI VI Daring)
const RAW=`mengubah|merubah|BI|E|menjadikan lain dari semula
risiko|resiko|SR|E|akibat kurang menyenangkan dari suatu tindakan
aktivitas|aktifitas|SR|E|kegiatan atau kesibukan
analisis|analisa|SR|M|penyelidikan untuk mengetahui keadaan sebenarnya
apotek|apotik|KB|E|tempat menjual dan meracik obat
atlet|atlit|KB|E|olahragawan yang mengikuti perlombaan
izin|ijin|EJ|E|persetujuan membolehkan
jadwal|jadual|KB|E|pembagian waktu berdasarkan rencana
kualitas|kwalitas|SR|E|tingkat baik buruknya sesuatu
nasihat|nasehat|KB|E|ajaran atau pelajaran yang baik
objek|obyek|SR|M|hal yang menjadi sasaran
subjek|subyek|SR|M|pokok pembicaraan; pelaku
praktik|praktek|SR|M|pelaksanaan secara nyata
sistem|sistim|SR|E|perangkat unsur yang teratur
teknik|tehnik|SR|E|cara membuat atau melakukan sesuatu
hakikat|hakekat|EJ|M|inti atau dasar sesuatu
kuitansi|kwitansi|SR|M|tanda terima pembayaran
silakan|silahkan|KK|E|kata untuk mempersilakan
standar|standard|SR|E|ukuran yang disepakati
teladan|tauladan|KB|M|sesuatu yang patut ditiru
frekuensi|frekwensi|SR|M|kekerapan terjadinya sesuatu
kategori|katagori|SR|E|golongan atau penggolongan
hierarki|hirarki|SR|X|urutan tingkatan
konsekuensi|konsekwensi|SR|M|akibat dari suatu perbuatan
metode|metoda|SR|M|cara teratur untuk mencapai maksud
persentase|prosentase|SR|M|perbandingan dalam hitungan per seratus
sekadar|sekedar|EJ|E|hanya; sekecil-kecilnya
andal|handal|KS|M|dapat dipercaya
antre|antri|KK|M|berdiri berderet menunggu giliran
azan|adzan|KB|M|seruan untuk salat
bus|bis|KB|M|kendaraan besar pengangkut penumpang
cabai|cabe|KB|M|tumbuhan berbuah pedas
detail|detil|KB|M|bagian yang kecil-kecil
ekstrem|ekstrim|KS|M|paling ujung; keras
hipotesis|hipotesa|IS|H|dugaan sementara
karier|karir|KB|M|perkembangan dalam pekerjaan
kompleks|komplek|KB|H|gabungan beberapa hal; rumit
lembap|lembab|KS|X|agak basah
mengonsumsi|mengkonsumsi|BI|M|memakai atau menghabiskan barang
memengaruhi|mempengaruhi|BI|H|mendatangkan akibat pada sesuatu
menganalisis|menganalisa|BI|H|menyelidiki secara terperinci
salat|sholat|EJ|M|ibadah dalam agama Islam
Jumat|Jum'at|EJ|E|hari keenam dalam sepekan
November|Nopember|EJ|M|bulan kesebelas
Februari|Pebruari|EJ|M|bulan kedua
khawatir|kuatir|KS|M|takut terhadap sesuatu yang belum terjadi
tobat|taubat|KK|M|menyesali dan berhenti berbuat dosa
rezeki|rejeki|KB|M|segala sesuatu penunjang hidup
terampil|trampil|KS|M|cakap menyelesaikan tugas
utang|hutang|KB|M|uang yang dipinjam
zaman|jaman|KB|E|jangka waktu yang panjang
konkret|kongkrit|KS|M|nyata; dapat dilihat
sanksi|sangsi|KB|M|tanggungan untuk memaksa penaatan
impor|import|KK|M|memasukkan barang dari luar negeri
ekspor|eksport|KK|M|mengirim barang ke luar negeri
kaidah|kaedah|KB|X|aturan yang sudah pasti
wudu|wudhu|EJ|X|bersuci sebelum salat`
export const WORDS:Word[]=RAW.split('\n').map((r,i)=>{const [baku,tidak,k,l,arti]=r.split('|');return{id:i+1,baku,tidak,kategori:K[k],level:L[l],arti}})
